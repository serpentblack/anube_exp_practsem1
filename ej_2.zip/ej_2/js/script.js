//Referencia a los elementos
const contenido = document.querySelector("#contenido");
const paragraphs = document.querySelectorAll("#contenido p");
let btnColor = document.querySelector("#btn-color");
const btnHideShow = document.querySelector("#btn-hide-show");
let estado = false;

//configuracion de enventos
btnColor.addEventListener("click", () => {
  if (estado) {
    contenido.style.backgroundColor = "#fff";
    contenido.style.color = "#000";
    estado = false;
  } else {
    contenido.style.backgroundColor = "#000";
    contenido.style.color = "#fff";
    estado = true;
  }
});

btnHideShow.addEventListener("click", function () {
  // Iteramos sobre cada párrafo para cambiar su propiedad display
  paragraphs.forEach(function (paragraph) {
    if (paragraph.style.display === "none") {
      // Si está invisible, lo hacemos visible
      paragraph.style.display = "block";
    } else {
      // Si está visible, lo hacemos invisible
      paragraph.style.display = "none";
    }
  });
});
