const tabla = document.querySelector("#tabla");
const generar = document.querySelector("#generar");
const resultado = document.querySelector("#resultado");

generar.addEventListener("click", () => {
  let numero = parseInt(tabla.value);
  let salida = `Tabla de multiplicar del número {numero} <br>`;

  for (i = 1; i <= 10; i++) {
    salida += `tabla x i = (tabla * i)`;
  }
  resultado.innerHTML = salida;
});
